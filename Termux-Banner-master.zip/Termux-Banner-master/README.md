# Termux Banner
#Script by Sutariya Parixit

Installation Step :

1) git clone https://github.com/Bhai4You/Termux-Banner


2) cd Termux-Banner


3) chmod +x requirement.sh


4) chmod +x t-ban.sh


5) bash requirement.sh


6) bash t-ban.sh

